package com.unityandroid.ide.data
import android.content.Context
import java.io.File

enum class ProjectTemplate(val title: String, val description: String) {
    CANYON_FLIGHT("Canyon Flight Starter", "Arcade flight with energy gates"),
    ENDLESS_RUNNER("Endless Runner", "Infinite obstacle-running starter"),
    PLATFORMER_2D("2D Platformer", "Side-scrolling platform game"),
    BLANK_3D("Blank 3D", "Minimal 3D project structure"),
    BLANK_2D("Blank 2D", "Minimal 2D project structure")
}
object TemplateFactory {
    fun create(context: Context, projectName: String, template: ProjectTemplate): File {
        val safe = projectName.replace(Regex("[^A-Za-z0-9_-]"), "_").ifBlank { "UnityProject" }
        val root = File(context.filesDir, "workspaces/$safe")
        check(root.exists() || root.mkdirs()) { "Could not create workspace directory" }
        listOf("Assets/Fonts","Assets/Materials","Assets/Plugins","Assets/Prefabs",
            "Assets/Resources","Assets/Scenes","Assets/Scripts","Assets/Sprites",
            "Packages","ProjectSettings").forEach { File(root, it).mkdirs() }
        File(root, "README.md").writeText("# $safe\n\nTemplate: ${template.title}\n${template.description}\n")
        File(root, "Packages/manifest.json").writeText(
            """{"dependencies":{"com.unity.modules.physics":"1.0.0","com.unity.modules.ui":"1.0.0"}}"""
        )
        File(root, "Assets/Scripts/FlightSession.cs").writeText(
            "using UnityEngine;\npublic class FlightSession : MonoBehaviour { public int score; void Start(){ score=0; } }\n"
        )
        File(root, "Assets/Scripts/RocketController.cs").writeText(
            "using UnityEngine;\npublic class RocketController : MonoBehaviour { public float speed=5f; void Update(){ transform.Translate(Vector3.forward*speed*Time.deltaTime); } }\n"
        )
        File(root, ".gitignore").writeText("Library/\nTemp/\nObj/\nBuild/\nLogs/\nUserSettings/\n")
        return root
    }
}
