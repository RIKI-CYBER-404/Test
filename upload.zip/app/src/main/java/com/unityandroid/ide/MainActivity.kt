package com.unityandroid.ide
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.unityandroid.ide.ui.UnityIdeApp
import com.unityandroid.ide.ui.theme.UnityIdeTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { UnityIdeTheme { UnityIdeApp() } }
    }
}
