package com.unityandroid.ide.ui.theme
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color

private val Purple = Color(0xFF7C4DFF)
private val DarkScheme = darkColorScheme(
    primary = Purple, secondary = Color(0xFF448AFF),
    background = Color(0xFF0D0D0F), surface = Color(0xFF1C1C1E),
    surfaceVariant = Color(0xFF252528)
)
private val LightScheme = lightColorScheme(
    primary = Purple, secondary = Color(0xFF448AFF),
    background = Color(0xFFF8F9FA), surface = Color.White,
    surfaceVariant = Color(0xFFF0F0F5)
)
enum class ThemeChoice { SYSTEM, DARK, LIGHT }
val LocalThemeChoice = compositionLocalOf { ThemeChoice.DARK }
val LocalSetTheme = compositionLocalOf<(ThemeChoice) -> Unit> { {} }

@Composable
fun UnityIdeTheme(content: @Composable () -> Unit) {
    var choice by remember { mutableStateOf(ThemeChoice.DARK) }
    val dark = when (choice) {
        ThemeChoice.SYSTEM -> isSystemInDarkTheme()
        ThemeChoice.DARK -> true
        ThemeChoice.LIGHT -> false
    }
    CompositionLocalProvider(
        LocalThemeChoice provides choice,
        LocalSetTheme provides { choice = it }
    ) {
        MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme, content = content)
    }
}
