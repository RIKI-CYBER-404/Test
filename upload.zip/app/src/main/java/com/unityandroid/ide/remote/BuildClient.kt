package com.unityandroid.ide.remote
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Client contract for a separately deployed Unity build worker. */
class BuildClient(private val baseUrl: String, private val tokenProvider: () -> String?) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build()

    fun submitBuild(projectUploadId: String, target: String = "Android"): Result<String> = runCatching {
        require(baseUrl.startsWith("https://")) { "Build endpoint must use HTTPS" }
        val token = tokenProvider() ?: error("Not authenticated")
        val body = JSONObject().put("projectUploadId", projectUploadId)
            .put("target", target).put("configuration", "Development").toString()
            .toRequestBody("application/json".toMediaType())
        val request = Request.Builder().url("$baseUrl/v1/builds")
            .header("Authorization", "Bearer $token").post(body).build()
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Build service HTTP ${response.code}")
            response.body?.string() ?: error("Empty build response")
        }
    }
}
