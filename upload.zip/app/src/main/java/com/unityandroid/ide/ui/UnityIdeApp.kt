package com.unityandroid.ide.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import com.unityandroid.ide.data.ProjectTemplate
import com.unityandroid.ide.data.TemplateFactory
import com.unityandroid.ide.ui.theme.*

private enum class Page(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    HOME("Projects", Icons.Default.Home), FILES("Files", Icons.Default.Folder),
    SCENE("Scene", Icons.Default.ViewInAr), CODE("Code", Icons.Default.Code),
    CONSOLE("Console", Icons.Default.Terminal), SETTINGS("Settings", Icons.Default.Settings)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UnityIdeApp() {
    var page by remember { mutableStateOf(Page.HOME) }
    var projectName by remember { mutableStateOf("No workspace") }
    var projectUri by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("Ready") }
    var showCreate by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("MyUnityGame") }
    var template by remember { mutableStateOf(ProjectTemplate.CANYON_FLIGHT) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            context.contentResolver.takePersistableUriPermission(uri,
                android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            projectUri = uri
            projectName = DocumentFile.fromTreeUri(context, uri)?.name ?: "Workspace"
            status = "Folder opened"
            page = Page.FILES
        }
    }
    Scaffold(
        topBar = { TopAppBar(title = {
            Column { Text("Unity Android IDE", fontWeight = FontWeight.Bold)
                Text(projectName, style = MaterialTheme.typography.labelSmall) }
        }, actions = { IconButton(onClick = { page = Page.SETTINGS }) { Icon(Icons.Default.Tune, "Settings") } }) },
        bottomBar = { NavigationBar {
            Page.values().forEach { p -> NavigationBarItem(
                selected = page == p, onClick = { page = p },
                icon = { Icon(p.icon, p.label) }, label = { Text(p.label, maxLines = 1) }
            ) }
        } },
        floatingActionButton = { if (page == Page.HOME) FloatingActionButton(onClick = { showCreate = true }) { Icon(Icons.Default.Add, "Create") } }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            when (page) {
                Page.HOME -> HomeScreen(projectName, status, { showCreate = true }, { picker.launch(null) })
                Page.FILES -> FileScreen(projectUri)
                Page.SCENE -> SceneScreen()
                Page.CODE -> CodeScreen()
                Page.CONSOLE -> ConsoleScreen(status)
                Page.SETTINGS -> SettingsScreen()
            }
        }
    }
    if (showCreate) AlertDialog(
        onDismissRequest = { showCreate = false },
        title = { Text("New Project") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(newName, { newName = it }, label = { Text("Project name") }, singleLine = true)
                Text("Package name: com.example.unity", style = MaterialTheme.typography.bodySmall)
                Text("Template", fontWeight = FontWeight.Bold)
                ProjectTemplate.values().forEach { item ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(template == item, { template = item })
                        Column { Text(item.title); Text(item.description, style = MaterialTheme.typography.bodySmall) }
                    }
                }
                Text("A local starter workspace will be created. Git initialization can be added after creation.",
                    style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(onClick = {
            runCatching { TemplateFactory.create(context, newName, template) }
                .onSuccess { folder ->
                    projectName = folder.name; projectUri = Uri.fromFile(folder)
                    status = "Created at ${folder.absolutePath}"; page = Page.FILES
                }.onFailure { status = it.message ?: "Creation failed" }
            showCreate = false
        }) { Text("Create") } },
        dismissButton = { TextButton(onClick = { showCreate = false }) { Text("Cancel") } }
    )
}

@Composable
private fun HomeScreen(name: String, status: String, onNew: () -> Unit, onOpen: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Your development workspace", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Create, inspect and manage game projects from your phone.") }
        item {
            Card {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("RECENT WORKSPACE", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall)
                    Text(name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(status, style = MaterialTheme.typography.bodySmall)
                    Button(onClick = onOpen, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.FolderOpen, null); Text("  Open existing folder") }
                }
            }
        }
        item { Text("Add workspace", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        item { ActionCard("New Project", "Create a mobile starter project", Icons.Default.AddBox, onNew) }
        item { ActionCard("Internal Storage", "Choose an existing project folder", Icons.Default.FolderOpen, onOpen) }
        item { ActionCard("Git Clone", "Remote clone workflow requires credentials and repository UI", Icons.Default.AccountTree) {} }
        item { Card { Column(Modifier.padding(16.dp)) {
            Text("Remote build pipeline", fontWeight = FontWeight.Bold)
            Text("A separately deployed Unity worker is required to compile actual Unity projects.", style = MaterialTheme.typography.bodySmall)
        } } }
    }
}

@Composable
private fun ActionCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, action: () -> Unit) {
    Card(onClick = action) { Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(30.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold); Text(subtitle, style = MaterialTheme.typography.bodySmall) }
        Icon(Icons.Default.ChevronRight, null)
    } }
}

@Composable
private fun FileScreen(uri: Uri?) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val root = remember(uri) { uri?.let { if (it.scheme == "file") null else DocumentFile.fromTreeUri(context, it) } }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Project Files", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        if (uri == null) Empty("No folder selected", "Open a workspace from Projects.")
        else if (uri.scheme == "file") {
            val folder = java.io.File(uri.path ?: "")
            val files = folder.listFiles()?.sortedBy { !it.isDirectory }.orEmpty()
            LazyColumn { items(files) { f ->
                ListItem(headlineContent = { Text(f.name) },
                    leadingContent = { Icon(if (f.isDirectory) Icons.Default.Folder else fileIcon(f.name), null) })
                HorizontalDivider()
            } }
        } else if (root != null) {
            val files = root.listFiles().sortedBy { !it.isDirectory }
            LazyColumn { items(files) { f ->
                ListItem(headlineContent = { Text(f.name ?: "Unnamed") },
                    leadingContent = { Icon(if (f.isDirectory) Icons.Default.Folder else fileIcon(f.name ?: ""), null) },
                    supportingContent = { Text(if (f.isDirectory) "Folder" else "File") })
                HorizontalDivider()
            } }
        }
    }
}
private fun fileIcon(name: String) = when (name.substringAfterLast('.', "").lowercase()) {
    "cs" -> Icons.Default.Code
    "unity" -> Icons.Default.ViewInAr
    "png", "jpg", "jpeg" -> Icons.Default.Image
    "json" -> Icons.Default.DataObject
    else -> Icons.Default.InsertDriveFile
}

@Composable
private fun SceneScreen() {
    var selected by remember { mutableStateOf("Rocket") }
    val objects = listOf("FlightSession", "CanyonBackdrop", "LandingStrip", "Rocket", "GateSpawner", "Main Camera", "Canvas", "EventSystem")
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Scene Hierarchy", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = {}) { Icon(Icons.Default.PlayArrow, "Play") }
            IconButton(onClick = {}) { Icon(Icons.Default.Pause, "Pause") }
            IconButton(onClick = {}) { Icon(Icons.Default.Stop, "Stop") }
        }
        LazyColumn(Modifier.weight(1f)) { items(objects) { obj ->
            ListItem(headlineContent = { Text(obj) },
                leadingContent = { Icon(Icons.Default.ViewInAr, null) },
                trailingContent = { TextButton(onClick = { selected = obj }) { Text("View") } },
                modifier = Modifier.clickable { selected = obj })
            HorizontalDivider()
        } }
        Card { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("Inspector · $selected", fontWeight = FontWeight.Bold)
            Property("Position", "0, 0, 0"); Property("Rotation", "0, 0, 0")
            Property("Scale", "1, 1, 1"); Property("Active", "Enabled")
        } }
    }
}
@Composable private fun Property(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(label); Text(value, fontWeight = FontWeight.Medium) }
}

@Composable
private fun CodeScreen() {
    var text by remember { mutableStateOf("using UnityEngine;\n\npublic class RocketController : MonoBehaviour\n{\n    public float speed = 5f;\n\n    void Update()\n    {\n        transform.Translate(Vector3.forward * speed * Time.deltaTime);\n    }\n}") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("C# Editor", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("RocketController.cs · sample buffer")
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = text, onValueChange = { text = it },
            modifier = Modifier.fillMaxSize(),
            textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace))
    }
}
@Composable
private fun ConsoleScreen(status: String) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Console", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF101014))) {
            Column(Modifier.padding(14.dp)) {
                Text("> unity-android-ide", color = Color.LightGray, fontFamily = FontFamily.Monospace)
                Text("[INFO] $status", color = Color(0xFF8BCF9A), fontFamily = FontFamily.Monospace)
                Text("[WARN] Remote build backend not configured", color = Color(0xFFFFC56B), fontFamily = FontFamily.Monospace)
            }
        }
    }
}
@Composable
private fun SettingsScreen() {
    val choice = LocalThemeChoice.current
    val setTheme = LocalSetTheme.current
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Appearance", style = MaterialTheme.typography.titleMedium)
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            ThemeChoice.values().forEachIndexed { i, item ->
                SegmentedButton(selected = choice == item, onClick = { setTheme(item) },
                    shape = SegmentedButtonDefaults.itemShape(i, ThemeChoice.values().size)) {
                    Text(item.name.lowercase().replaceFirstChar { it.uppercase() })
                }
            }
        }
        HorizontalDivider()
        Text("Build target: Android APK")
        Text("Connect a secured HTTPS Unity build worker to enable actual APK compilation.")
        Text("Unity Android IDE 1.0.0 · API 26+", style = MaterialTheme.typography.labelSmall)
    }
}
@Composable
private fun Empty(title: String, message: String) {
    Column(Modifier.fillMaxWidth().padding(30.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.FolderOff, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(40.dp))
        Text(title, fontWeight = FontWeight.Bold); Text(message)
    }
}
