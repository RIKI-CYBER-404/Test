# Remote Unity Build Worker

The Android APK cannot contain the official Unity Editor or Unity's build pipeline. Deploy a separate secured worker with a licensed Unity installation and Android Build Support.

## API contract
- POST /v1/uploads — accept a streamed project archive or issue a temporary upload URL.
- POST /v1/builds — accept {projectUploadId, target, configuration}; return buildId.
- GET /v1/builds/{buildId} — return queued/running/succeeded/failed and structured logs.
- GET /v1/builds/{buildId}/artifact — return a short-lived APK download URL.

## Worker responsibilities
- Isolated VM/container and pinned Unity version.
- Validate archive paths and reject path traversal, escaping symlinks and oversized uploads.
- Queue jobs, create disposable workspaces and clean up after builds.
- Invoke Unity in batch mode using a controlled Editor build script.
- Protect signing keystores server-side.
- HTTPS, OAuth/short-lived tokens, rate limits, quotas, audit logs and private artifact storage.

Example worker invocation:
```bash
Unity -batchmode -quit -projectPath /jobs/JOB/project \
  -executeMethod BuildEntry.BuildAndroid -logFile /jobs/JOB/unity.log
```

The worker implementation itself must be deployed with your Unity license, signing configuration, server credentials and infrastructure. This repository includes the Android-side client contract, not a fake build service.
