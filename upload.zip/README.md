# Unity Android IDE — Android Studio source

## Open
1. Install Android Studio and JDK 17.
2. Open this directory in Android Studio.
3. Sync Gradle.
4. Run the `app` configuration on an Android 8.0+ device/emulator.

## Included in this starter implementation
- Package `com.unityandroid.ide`, minSdk 26.
- Kotlin + Jetpack Compose + Material 3.
- Dark, Light and System theme switching.
- Home dashboard, create project dialog and five starter templates.
- App-private local workspace generation.
- SAF folder picker for existing workspaces.
- Basic file listing and file-type icons.
- Scene hierarchy and sample inspector.
- Editable C# text buffer.
- Console and settings.
- Remote build client contract and backend deployment requirements.

## Not yet production-complete
The app is an executable foundation, not a full Unity Editor replacement. The C# buffer is not yet a persisted syntax-highlighting multi-tab editor; scene hierarchy uses sample data; Git workflows, Roslyn language services, Unity YAML parsing, live Unity runtime preview, project upload/status polling and artifact download remain integration work. Starter project generation does not create a fully validated Unity project with all `.meta` files and serialized scenes.

Actual Unity APK compilation requires a separately deployed build worker with a licensed Unity installation and Android Build Support. See `backend/README.md`. Do not place permanent credentials in the APK.


## GitHub Actions CI

Workflow: `.github/workflows/android.yml`

It runs on pushes and pull requests to `main`/`master`, and can also be started manually from the GitHub Actions tab. It:
1. Checks out the repository.
2. Installs JDK 17 and Android SDK API 35.
3. Uses Gradle 8.9 (compatible with Android Gradle Plugin 8.7.3).
4. Runs `:app:assembleDebug`.
5. Uploads `UnityAndroidIDE-debug-apk` as a downloadable workflow artifact.

### Publish to GitHub

1. Create a GitHub repository.
2. Extract this ZIP and upload/commit all files, including the hidden `.github` folder.
3. Set the default branch to `main` (or keep `master`; both are configured).
4. Open **Actions** and enable workflows if GitHub asks.
5. Push a commit or choose **Android CI → Run workflow**.
6. Open the completed run and download the `UnityAndroidIDE-debug-apk` artifact.

The workflow builds a debug APK. It does not create a signed Play Store release APK. Release signing should be added with GitHub Actions Secrets (`ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD`) and must never commit signing keys or passwords.

The workflow does not deploy a Unity build server. Actual Unity project APK builds still require the separately licensed Unity build worker described in `backend/README.md`.
